package com.wraithcode.wraithEcommerce.Prevelant;

import com.wraithcode.wraithEcommerce.Model.Users;

public class Prevelant {

    public static Users currentOnlineUser;
    public static final String userPhoneKey = "UserPhone";
    public static final String userPasswordKey = "UserPassword";

}
