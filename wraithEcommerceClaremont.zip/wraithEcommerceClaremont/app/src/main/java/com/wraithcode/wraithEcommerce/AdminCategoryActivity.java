package com.wraithcode.wraithEcommerce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class AdminCategoryActivity extends AppCompatActivity {

    private ImageView painting, ceramics, art, furniture, photography, prints, fabrics, sculptures;

    //attempt to add paintings category
    //private ImageView paintings, vault;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_category);

        painting = (ImageView) findViewById(R.id.painting);
        ceramics = (ImageView) findViewById(R.id.ceramics);
        art = (ImageView) findViewById(R.id.art);
        furniture = (ImageView) findViewById(R.id.furniture);
        photography = (ImageView) findViewById(R.id.photography);
        prints = (ImageView) findViewById(R.id.prints);
        fabrics = (ImageView) findViewById(R.id.fabrics);
        sculptures = (ImageView) findViewById(R.id.sculpture);



        painting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminCategoryActivity.this, AdminAddProductActivity.class);
                intent.putExtra("category", "painting");
                startActivity(intent);

            }
        });

        ceramics.setOnClickListener(new View.OnClickListener() {
           @Override
          public void onClick(View view) {
              Intent intent = new Intent(AdminCategoryActivity.this, AdminAddProductActivity.class);
              intent.putExtra("category", "ceramics");
              startActivity(intent);

         }
        });

        art.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminCategoryActivity.this, AdminAddProductActivity.class);
                intent.putExtra("category", "flip flops");
                startActivity(intent);
            }
        });

        furniture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminCategoryActivity.this, AdminAddProductActivity.class);
                intent.putExtra("category", "furniture");
                startActivity(intent);
            }
        });

        photography.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminCategoryActivity.this, AdminAddProductActivity.class);
                intent.putExtra("category", "photography");
                startActivity(intent);

            }
        });

        prints.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminCategoryActivity.this, AdminAddProductActivity.class);
                intent.putExtra("category", "prints");
                startActivity(intent);

            }
        });

        fabrics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminCategoryActivity.this, AdminAddProductActivity.class);
                intent.putExtra("category", "fabrics");
                startActivity(intent);
            }
        });

        sculptures.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminCategoryActivity.this, AdminAddProductActivity.class);
                intent.putExtra("category", "sculptures");
                startActivity(intent);
            }
        });
    }
}
